package classeabstrata;

public abstract class ContaBancaria 
{
    protected int nmr;
    protected double saldo;
    private boolean corrente;
    private boolean poupanca;
    
    public ContaBancaria(int nmr,double saldo, boolean corrente, boolean poupanca)
    {
        this.nmr = nmr;
        this.saldo = saldo;
        this.corrente = false;
        this.poupanca = false;
    }
    
    public abstract void saque(double valorSaque);
    
    public void deposito(double valorDep)
    {
        this.saldo += valorDep;
        System.out.println("Deposito realizado com sucesso.");
    }
    
    @Override
    public String toString() {
        return "Conta Bancaria:" + ""+ nmr +" "+saldo+"";  
    }
}
