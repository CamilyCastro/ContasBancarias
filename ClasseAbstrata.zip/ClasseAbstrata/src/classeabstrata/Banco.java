package classeabstrata;

import java.util.ArrayList;

public class Banco
{
    private ArrayList<ContaBancaria> contas;
    
    public Banco(ArrayList<ContaBancaria> contas)
    {
        this.contas = contas;
    }
    
    public void inserirContas(ContaBancaria novaConta)
    {
        this.contas.add(novaConta);
    }
    
   public void imprimirContas()
   {
        for(ContaBancaria conta: this.contas)
        {
            System.out.println(conta.toString());
        }
    }
}
