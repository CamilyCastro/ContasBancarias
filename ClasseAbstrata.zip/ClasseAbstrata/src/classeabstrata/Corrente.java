package classeabstrata;

public class Corrente extends ContaBancaria
{
    private double limite;
    
    public Corrente(int nmr, double saldo, double limite, boolean corrente, boolean poupanca)
    {
        super(nmr, saldo, true, false);
        this.limite = limite; 
    }
    
    @Override
    public void saque(double valorSaque)
    {
        if(valorSaque < this.limite){
            this.saldo -= valorSaque;
            System.out.println("Saque realizado com sucesso.");
        }else
            System.out.println("Impossivel realizar transação, pois o valor limite de saque foi ultrapassado.");
    }
    
    @Override
    public String toString() {
        return "Conta Bancaria:" + ""+ nmr +" "+saldo+""; 
    }
}
