package classeabstrata;

import java.util.ArrayList;

public class ClasseAbstrata {

    public static void main(String[] args) 
    {
        ContaBancaria c1 = new Corrente(123, 2000, 1000,true, false);
        ContaBancaria c2 = new Corrente(124, 5000, 2500, true, false);
        ContaBancaria c3 = new Poupanca(125, 4000, false, true);
        ContaBancaria c4 = new Poupanca(126, 500, false, true);
        
        ArrayList<ContaBancaria> contas = new ArrayList();
        
        Banco banco = new Banco(contas);
        banco.inserirContas(c1);
        banco.inserirContas(c2);
        banco.inserirContas(c3);
        banco.inserirContas(c4);
        
        banco.imprimirContas();
        
        c1.saque(500);
        c2.saque(2700);
        c3.saque(1000);
        c4.deposito(2000);
        
        banco.imprimirContas();
    }
    
}
