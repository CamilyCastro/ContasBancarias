package classeabstrata;

public class Poupanca extends ContaBancaria
{
    public Poupanca(int nmr, double saldo, boolean corrente, boolean poupanca)
    {
        super(nmr, saldo, false, true);
    }
    
    @Override
    public void saque(double valorSaque)
    {
        this.saldo -= valorSaque;
        System.out.println("Saque realizado com sucesso.");
    }
    
    @Override
    public String toString() {
        return "Conta Bancaria:" + ""+ nmr +" "+saldo+""; 
    }
}
